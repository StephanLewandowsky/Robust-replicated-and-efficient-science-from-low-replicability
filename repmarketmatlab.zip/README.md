# replication_market

Philosophy JRC review: lots of interesting simulation-based papers.